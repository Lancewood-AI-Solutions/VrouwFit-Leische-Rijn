<?php
/**
 * VrouwFit theme functions.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function vrouwfit_enqueue_assets() {
	wp_enqueue_style(
		'vrouwfit-style',
		get_stylesheet_uri(),
		array(),
		wp_get_theme()->get( 'Version' )
	);
}
add_action( 'wp_enqueue_scripts', 'vrouwfit_enqueue_assets' );

function vrouwfit_setup() {
	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'responsive-embeds' );
	add_theme_support( 'editor-styles' );
}
add_action( 'after_setup_theme', 'vrouwfit_setup' );

/**
 * Simple contact form shortcode used on the front page.
 * Replace the recipient address with the site's real inbox before launch.
 */
function vrouwfit_contact_form_shortcode() {
	$notice = '';
	if ( isset( $_GET['vf_sent'] ) && '1' === $_GET['vf_sent'] ) {
		$notice = '<p class="vf-form-notice" role="status">Bedankt! Je bericht is verzonden.</p>';
	}
	if ( isset( $_GET['vf_sent'] ) && '0' === $_GET['vf_sent'] ) {
		$notice = '<p class="vf-form-notice" role="alert">Het bericht kon niet worden verzonden. Probeer het later opnieuw.</p>';
	}

	ob_start(); ?>
	<form class="vf-form" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" method="post">
		<?php echo $notice; ?>
		<input type="hidden" name="action" value="vrouwfit_contact">
		<?php wp_nonce_field( 'vrouwfit_contact', 'vrouwfit_nonce' ); ?>

		<label for="vf-name">Naam *</label>
		<input id="vf-name" name="name" type="text" required>

		<label for="vf-email">E-mailadres *</label>
		<input id="vf-email" name="email" type="email" required>

		<label for="vf-message">Bericht *</label>
		<textarea id="vf-message" name="message" required></textarea>

		<button type="submit">Verzenden</button>
	</form>
	<?php
	return ob_get_clean();
}
add_shortcode( 'vrouwfit_contact_form', 'vrouwfit_contact_form_shortcode' );

function vrouwfit_handle_contact() {
	if (
		! isset( $_POST['vrouwfit_nonce'] ) ||
		! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['vrouwfit_nonce'] ) ), 'vrouwfit_contact' )
	) {
		wp_die( 'Ongeldige aanvraag.' );
	}

	$name    = isset( $_POST['name'] ) ? sanitize_text_field( wp_unslash( $_POST['name'] ) ) : '';
	$email   = isset( $_POST['email'] ) ? sanitize_email( wp_unslash( $_POST['email'] ) ) : '';
	$message = isset( $_POST['message'] ) ? sanitize_textarea_field( wp_unslash( $_POST['message'] ) ) : '';

	$redirect = wp_get_referer() ? wp_get_referer() : home_url( '/' );

	if ( ! $name || ! is_email( $email ) || ! $message ) {
		wp_safe_redirect( add_query_arg( 'vf_sent', '0', $redirect ) );
		exit;
	}

	$to      = get_option( 'admin_email' );
	$subject = sprintf( 'Nieuw VrouwFit contactbericht van %s', $name );
	$body    = "Naam: {$name}\nE-mail: {$email}\n\nBericht:\n{$message}\n";
	$headers = array( 'Reply-To: ' . $name . ' <' . $email . '>' );

	$sent = wp_mail( $to, $subject, $body, $headers );
	wp_safe_redirect( add_query_arg( 'vf_sent', $sent ? '1' : '0', $redirect ) );
	exit;
}
add_action( 'admin_post_nopriv_vrouwfit_contact', 'vrouwfit_handle_contact' );
add_action( 'admin_post_vrouwfit_contact', 'vrouwfit_handle_contact' );
